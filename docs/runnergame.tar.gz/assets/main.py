import  pygame
import asyncio
from sys import exit
from random import randint, choice


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        player_walk1 = pygame.image.load('Player/player_walk_1.png').convert_alpha()
        player_walk2 = pygame.image.load('Player/player_walk_2.png').convert_alpha()
        self.player_walk = [player_walk1, player_walk2]
        self.player_index = 0
        self.player_jump = pygame.image.load('Player/jump.png').convert_alpha()

        self.image = self.player_walk[self.player_index]
        self.rect = self.image.get_rect(midbottom=(80, 300))
        self.gravity = 0

        self.jump_sound = pygame.mixer.Sound('Audio/jump.ogg')
        self.jump_sound.set_volume(0.3)

    def player_input(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE] and self.rect.bottom >= 300:
            self.gravity = -20
            self.jump_sound.play()

    def apply_gravity(self):
        self.gravity += 1
        self.rect.y += self.gravity
        if self.rect.bottom >= 300:
            self.rect.bottom = 300

    def animation_state(self):
        if self.rect.bottom < 300:
            self.image = self.player_jump
        else:
            self.player_index += 0.1
            if self.player_index >= len(self.player_walk):
                self.player_index = 0
            self.image = self.player_walk[int(self.player_index)]

    def update(self):
        self.player_input()
        self.apply_gravity()
        self.animation_state()


class Obstacle(pygame.sprite.Sprite):
    def __init__(self, type):
        super().__init__()
        if type == 'fly':
            fly_1 = pygame.image.load('Fly/Fly1.png').convert_alpha()
            fly_2 = pygame.image.load('Fly/Fly2.png').convert_alpha()
            self.frames = [fly_1, fly_2]
            y_pos = 210

        else:
            snail_1 = pygame.image.load('Snail/snail1.png').convert_alpha()
            snail_2 = pygame.image.load('Snail/snail2.png').convert_alpha()
            self.frames = [snail_1, snail_2]
            y_pos = 300

        self.animation_index = 0
        self.image = self.frames[self.animation_index]
        self.rect = self.image.get_rect(midbottom=(randint(900, 1100), y_pos))

    def animation_state(self):
        self.animation_index += 0.1
        if self.animation_index >= len(self.frames): self.animation_index = 0
        self.image = self.frames[int(self.animation_index)]

    def update(self):
        self.animation_state()
        self.rect.x -= 6
        self.destroy()

    def destroy(self):
        if self.rect.x <= -100: self.kill()


def display_score():
    current_time = int(pygame.time.get_ticks() / 1000) - start_time
    score_surface = test_font.render(f'Score:{current_time}', False, (64, 64, 64))
    score_rectangle = score_surface.get_rect(center=(400, 50))
    screen.blit(score_surface, score_rectangle)
    return current_time


def collision_sprite():
    if pygame.sprite.spritecollide(player.sprite, obstacle_group, False):
        obstacle_group.empty()
        return False
    else:
        return True



pygame.init()

screen = pygame.display.set_mode((800, 400))
pygame.display.set_caption('Runner')
clock = pygame.time.Clock()
test_font = pygame.font.Font('Font/Pixeltype.ttf', 70)
game_active = False
start_time = 0
score = 0
bg_music = pygame.mixer.Sound('Audio/music.ogg')
bg_music.play(loops=-1)

player = pygame.sprite.GroupSingle()
player.add(Player())
obstacle_group = pygame.sprite.Group()

sky_surface = pygame.image.load('Sky.png').convert_alpha()
ground_surface = pygame.image.load('ground.png').convert_alpha()


# obstacles section - snail
snail_frame1 = pygame.image.load('Snail/snail1.png').convert_alpha()
snail_frame2 = pygame.image.load('Snail/snail2.png').convert_alpha()
snail_frames = [snail_frame1, snail_frame2]
snail_frame_index = 0
snail_surface = snail_frames[snail_frame_index]

# fly
fly_frame1 = pygame.image.load('Fly/Fly1.png').convert_alpha()
fly_frame2 = pygame.image.load('Fly/Fly2.png').convert_alpha()
fly_frames = [fly_frame1, fly_frame2]
fly_frame_index = 0
fly_surface = fly_frames[fly_frame_index]

obstacle_rectangle_list = []

player_walk1 = pygame.image.load('Player/player_walk_1.png').convert_alpha()
player_walk2 = pygame.image.load('Player/player_walk_2.png').convert_alpha()
player_walk = [player_walk1, player_walk2]
player_index = 0
player_jump = pygame.image.load('Player/jump.png').convert_alpha()
player_surface = player_walk[player_index]

player_rectangle = player_walk1.get_rect(midbottom=(80, 300))
player_gravity = 0
player_stand = pygame.image.load('Player/player_stand.png').convert_alpha()
player_stand = pygame.transform.rotozoom(player_stand, 0, 2)
player_stand_rectangle = player_stand.get_rect(center=(400, 200))

game_name = test_font.render('Runner', False, (111, 196, 169))
game_name_rectangle = game_name.get_rect(center=(400, 80))

game_message = test_font.render('Press space to run', False, (111, 196, 169))
game_message_rectangle = game_message.get_rect(center=(400, 330))

# Timer section
# pygame.time.set_timer doesn't work in the browser (pygbag), so obstacles
# are spawned by checking the clock each frame instead.
OBSTACLE_INTERVAL = 1500  # ms between obstacles
next_obstacle_time = 0

async def main():
    global game_active, start_time, score, player_gravity, next_obstacle_time
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if game_active:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE and player_rectangle.bottom == 300:
                        player_gravity = -20

            else:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    print('space pressed')
                    game_active = True

                    start_time = int(pygame.time.get_ticks() / 1000)  # resets score
                    next_obstacle_time = pygame.time.get_ticks() + OBSTACLE_INTERVAL

        if game_active and pygame.time.get_ticks() >= next_obstacle_time:
            obstacle_group.add(Obstacle(choice(['fly', 'snail', 'snail', 'snail'])))
            next_obstacle_time += OBSTACLE_INTERVAL

        if game_active:
            screen.blit(sky_surface, (0, 0))
            screen.blit(ground_surface, (0, 300))
            score = display_score()

            # Player section
            player.draw(screen)
            player.update()
            obstacle_group.draw(screen)
            obstacle_group.update()

            # collision - game over
            game_active = collision_sprite()

        else:
            screen.fill((94, 129, 162))
            screen.blit(player_stand, player_stand_rectangle)
            obstacle_rectangle_list.clear()
            player_rectangle.midbottom = (80, 100)
            player_gravity = 0

            score_message = test_font.render(f'Your score: {score}', False, (111, 196, 169))
            score_message_rectangle = score_message.get_rect(center=(400, 330))
            screen.blit(game_name, game_name_rectangle)
            if score == 0:
                screen.blit(game_message, game_message_rectangle)
            else:
                screen.blit(score_message, score_message_rectangle)

        pygame.display.update()
        clock.tick(60)
        await asyncio.sleep(0)
asyncio.run(main())
